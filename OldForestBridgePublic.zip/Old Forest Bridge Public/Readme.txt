Thank you very much for downloading my battle map,
I hope you have fun with it!

If you'd like to support my work please visit my Patreon at:
http://patreon.com/dicegrimorium

By pledging you can get access to

- High Resolution Maps
- Gridless Versions
- Alternate Variants
- Map Tokens
- PSDs
- And More!

Your support makes all these maps possible!